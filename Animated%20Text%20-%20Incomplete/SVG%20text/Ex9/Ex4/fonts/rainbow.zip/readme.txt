Rainbow font inspired on Lana Del Rey's typeface created by HawaiianTropic.

This font is only for personal use, do NOT ask for a comercial licence since i don't own the rights of the original design. This font is just a fan-made project.

Thank You.

Luis Duarte (HawaiianTropic).